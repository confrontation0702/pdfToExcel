#
# The content of this file will be filled in with meaningful data
# when creating an archive using `git archive` or by downloading an
# archive from github, e.g. from github.com/.../archive/develop.zip
#
rev = "1eadfa55f2"     # abbreviated commit hash
commit = "1eadfa55f2ad21539d7773dfb23f27ebd9db26d8"  # commit hash
date = "2019-11-16 11:19:06 +0100"   # commit date
author = "Hartmut Goebel <h.goebel@crazy-compilers.com>"
ref_names = "HEAD -> develop"  # incl. current branch
commit_message = """Move a comment.
"""
